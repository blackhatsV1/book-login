<?php 
 
 $con = mysqli_connect("localhost","root","","book_db") or die("Couldn't connect");

?>