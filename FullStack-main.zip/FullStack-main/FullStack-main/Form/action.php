<?php
session_start(); // Start session

// Include database connection
include("php/config.php");

if(isset($_POST['submit'])){
    // Sanitize user inputs
    $email = mysqli_real_escape_string($con, $_POST['email']);
    $password = mysqli_real_escape_string($con, $_POST['password']);

    // Query to fetch user details based on email and password
    $query = "SELECT * FROM book_registration WHERE email='$email' AND Password='$password'";
    $result = mysqli_query($con, $query);

    if($result) {
        // Fetch user data
        $row = mysqli_fetch_assoc($result);
        if($row) {
            // Set session variables upon successful login
            $_SESSION['valid'] = $row['email'];
            $_SESSION['username'] = $row['firstName'];
            $_SESSION['email'] = $row['email'];
            $_SESSION['id'] = $row['id'];

            // Redirect user to home page
            header("Location: ../Landing/home.php");
            exit(); // Ensure script execution stops after redirection
        } else {
            // Invalid credentials, display error message
            echo "<div class='message'>
                    <p>Wrong Username or Password</p>
                  </div> <br>";
            echo "<a href='login.php'><button class='btn'>Go Back</button>";
        }
    } else {
        // Error in query execution
        die("Error: " . mysqli_error($con));
    }
}
?>
